## Seep - A Tech Innovative Program

This web app is currently hosted on  [here](https://seesupportcenter.org) 



## Technologies


 - NextJs
 - Tailwind CSS



## Deploy on Vercel

Deployed on vercel [here](https://seep-project.vercel.app) 

Happy viewing ✌.
