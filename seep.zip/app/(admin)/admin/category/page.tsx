import React from 'react'
import AdminNav from '../_components/AdminNav'

const CategoryPage = () => {
  return (
    <div>
        <AdminNav title='Category' user='Joy'/>

      
    </div>
  )
}

export default CategoryPage
