import SupportForm from '@/app/(support)/support/_components/SupportForm'
import React from 'react'

const DonateModal = () => {

  return (
    <div>
       <SupportForm/>
    </div>
  )
}

export default DonateModal
