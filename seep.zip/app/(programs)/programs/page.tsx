import React from 'react'
import ProgramHero from './_components/ProgramHero'
import ProgramsAndBeneficiary from './_components/ProgramsAndBeneficiary'

const page = () => {
  return (
    <div>
        <ProgramHero/>
        <ProgramsAndBeneficiary/>
      
    </div>
  )
}

export default page
