import React from 'react'
import SupportHero from './_components/SupportHero'
import SupportForm from './_components/SupportForm'

const page = () => {
  return (
    <div>
        <SupportHero/>
        <SupportForm/>
      
    </div>
  )
}

export default page
