import React from 'react'
import GalleryHero from './_components/GalleryHero'
import Gallery from './_components/Gallery'

const page = () => {
  return (
    <div>
        <GalleryHero/>
        <Gallery/>
      
    </div>
  )
}

export default page
